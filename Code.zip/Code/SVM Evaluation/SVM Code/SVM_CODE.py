from nltk.corpus import stopwords 
from nltk.tokenize import word_tokenize 
import csv
from nltk.stem import PorterStemmer 
import numpy as np
from sklearn.svm import SVC



with open('Tweet_Sentiments2.csv') as csv_file:
    csv_reader = csv.reader(csv_file, delimiter=',')
    line_count = 0
    for row in csv_reader:
        if line_count == 0:
            print(f'Column names are {", ".join(row)}')
            line_count += 1
        else:
            tweets[line_count]= row[7]
			labels[line_count]= row[12]
            line_count += 1
    print(f'Processed {line_count} lines.')

stop_words = set(stopwords.words('english')) 

word_tokens = word_tokenize(tweets) 

word_tokens = [w for w in word_tokens if not w in stop_words] 

tweets = [] 

for w in word_tokens: 
	if w not in stop_words:
		tweets.append(ps.stem(w)) 

print(word_tokens) 
print(tweets) 


def computetweetsTFDict(tweets):
    """ Returns a tf dictionary for each tweets whose keys are all 
    the unique words in the tweets and whose values are their 
    corresponding tf.
    """
    #Counts the number of times the word appears in tweets
    tweetsTFDict = {}
    for word in tweets:
        if word in tweetsTFDict:
            tweetsTFDict[word] += 1
        else:
            tweetsTFDict[word] = 1
    #Computes tf for each word           
    for word in tweetsTFDict:
        tweetsTFDict[word] = tweetsTFDict[word] / len(tweets)
    return tweetsTFDict
	
	  def computeCountDict():
    """ Returns a dictionary whose keys are all the unique words in
    the dataset and whose values count the number of tweetss in which
    the word appears.
    """
    countDict = {}
    # Run through each tweets's tf dictionary and increment countDict's (word, doc) pair
    for tweets in tfDict:
        for word in tweets:
            if word in countDict:
                countDict[word] += 1
            else:
                countDict[word] = 1
    return countDict

  #Stores the tweets count dictionary
  countDict = computeCountDict()
  
    def computetweetsTFIDFDict(tweetsTFDict):
    """ Returns a dictionary whose keys are all the unique words in the
    tweets and whose values are their corresponding tfidf.
    """
    tweetsTFIDFDict = {}
    #For each word in the tweets, we multiply its tf and its idf.
    for word in tweetsTFDict:
        tweetsTFIDFDict[word] = tweetsTFDict[word] * idfDict[word]
    return tweetsTFIDFDict

  #Stores the TF-IDF dictionaries
  tfidfDict = [computetweetsTFIDFDict(tweets) for tweets in tfDict]
  
  

X = tfidfDict
y = labels

clf = SVC(gamma='auto')
clf.fit(X, y) 

print(clf.predict([[-0.8, -1]]))