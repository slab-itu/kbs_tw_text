# This R script is to count total number of positive,negative and neutral tweets from output files of SentiStrength tool

#Place input file (CSV format) in below directory or update the directory accordingly

setwd("E:/MS Study/MS Thesis/Twitter Data")
df<-read.csv("Sentiments of all tweets.csv",row.names=NULL)
ALT_ID<-df$ALTMETRIC_ID
TWEET_ID<-df$TWEET_ID
dataframe<-data.frame()

Pos<-c(2,3,4,5)
Neg<-c(-2,-3,-4,-5)

w<-length(ALT_ID)

for(i in 1:w)
{
print(i)
ALTMETRIC_ID<-ALT_ID[i]
library(dplyr)
df1<- filter(df,df$ALTMETRIC_ID == ALT_ID[i])
Total_Tweets<-length(df1$ALTMETRIC_ID)


a<-subset(df1$Positive,!grepl("^[[:space:]]*$",df1$Positive))

b<-subset(df1$Negative,!grepl("^[[:space:]]*$",df1$Negative))

Positive_Count<-length(a[a %in% Pos])
Negative_Count<-length(b[b %in% Neg])

Neutral_Count<-length(a[a=='1' & b=='-1'])

tempdb <- data.frame(ALTMETRIC_ID,Total_Tweets,Positive_Count,Negative_Count,Neutral_Count)


dataframe<-rbind(dataframe,tempdb)

}
dataframe1<-unique(dataframe)
write.csv(dataframe1, file = "Sentiment_Count.csv")

