#SentiStrength tool retun output in txt file, below script can be used to convert txt into CSV file

#Place input file in below directory or update the directory accordingly

setwd("E:/MS Study/MS Thesis/Twitter Data")


mydata <- read.table(file="1+results.txt",sep="\t",fill = TRUE,row.names=NULL,quote = "") 
#print(mydata$V1)

write.csv(mydata, file = "1.csv")



mydata <- read.table(file="2+results.txt",sep="\t",fill = TRUE,row.names=NULL,quote = "") 
#print(mydata$V1)

write.csv(mydata, file = "2.csv")



mydata <- read.table(file="3+results.txt",sep="\t",fill = TRUE,row.names=NULL,quote = "") 
#print(mydata$V1)

write.csv(mydata, file = "3.csv")




mydata <- read.table(file="4+results.txt",sep="\t",fill = TRUE,row.names=NULL,quote = "") 
#print(mydata$V1)

write.csv(mydata, file = "4.csv")




mydata <- read.table(file="5+results.txt",sep="\t",fill = TRUE,row.names=NULL,quote = "") 
#print(mydata$V1)

write.csv(mydata, file = "5.csv")



mydata <- read.table(file="6+results.txt",sep="\t",fill = TRUE,row.names=NULL,quote = "") 
#print(mydata$V1)

write.csv(mydata, file = "6.csv")



mydata <- read.table(file="7+results.txt",sep="\t",fill = TRUE,row.names=NULL,quote = "") 
#print(mydata$V1)

write.csv(mydata, file = "7.csv")


mydata <- read.table(file="8+results.txt",sep="\t",fill = TRUE,row.names=NULL,quote = "") 
#print(mydata$V1)

write.csv(mydata, file = "8.csv")



mydata <- read.table(file="9+results.txt",sep="\t",fill = TRUE,row.names=NULL,quote = "") 
#print(mydata$V1)

write.csv(mydata, file = "9.csv")



mydata <- read.table(file="10+results.txt",sep="\t",fill = TRUE,row.names=NULL,quote = "") 
#print(mydata$V1)

write.csv(mydata, file = "10.csv")