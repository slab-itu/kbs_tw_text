#Sentistrength takes one text in one line as input therefore below script is used to remove any linke breaks in tweet text

#Place input files (csv format) in below directory or update the directory accordingly

setwd("E:/MS Study/MS Thesis/Twitter Data")

file_list <- list.files()
list_length<-length(file_list)
for (listi in 1:list_length)
{
print(file_list[listi])
df<-read.csv(file_list[listi],row.names=NULL)
id2<-(df$id2)
c<-(df$TEXT)
citation.title<-(df$citation.title)
TEXT<-gsub("[\r\n]", "", c)
data <- data.frame(id2,TEXT,citation.title)

write.csv(data, file=paste(listi,"Cleaned.csv"))
}





