# This R script is to clean tweet text by removing twitter affordances i.e. URLs, hashtags(#) and user mentions (@username) 
# as they are considered not to carry any opinion about article

#Place input file in below directory or update the directory accordingly

setwd("E:/MS Study/MS Thesis/Twitter Data")

df<-read.csv("Input file.csv",row.names=NULL)

ALTMETRIC_ID<-(df$altmetric_id)
TWEET_ID<-(df$TWEET_ID)
c<-(df$TEXT)
citation.title<-(df$citation.title)

c<-gsub('http.*\\s*', '', c)
c<-gsub("@\\w+ *", "", c)
c<-gsub("\\n", "", c)
TEXT<-gsub("#","",c)

citation.title<-gsub("[[:punct:]]", " ", citation.title)
citation.title<-gsub("b'","",citation.title)

citation.title<-gsub("\\n","",citation.title)

data <- data.frame(ALTMETRIC_ID,TWEET_ID,TEXT,citation.title)
write.csv(data, file = "Outputfile.csv",na="")


