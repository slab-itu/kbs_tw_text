#After removing paper terms from tweet text some of the tweets become epty,below script can be used to remove such rows

setwd("E:/MS Study/Thesis")

df<-read.csv("final1.csv",row.names=NULL)

df <- df[!(df$TEXT == "" | is.na(df$TEXT)), ]

write.csv(df, file = "final2.csv")