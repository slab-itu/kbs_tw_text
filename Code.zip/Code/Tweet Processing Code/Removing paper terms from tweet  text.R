#Tweets text sometimes contains research specific terms that are taken from papers� title and are not the actual opinion towards that research article.
#Any such terms were removed from tweets� text by using this R script


#Place all the input files(csv format) that contain tweet text in the directory below or update directory accordingly

setwd("E:/MS Study/MS Thesis/Twitter Data")

file_list <- list.files()
list_length<-length(file_list)
for (listi in 1:list_length)
{
print(listi)
df<-read.csv(file_list[listi],row.names=NULL,stringsAsFactors=FALSE)
df = as.data.frame(sapply(df, tolower)) 
df<-subset(df,!grepl("^[[:space:]]*$",TEXT))
id2<-(df$id2)

citation.title<-(df$citation.title)

tweet<-strsplit(as.character(df$TEXT), " ")
a<-(df$TEXT)

#Below part is removing helping words, nuemerics or single alphabets from text

a<-gsub("[[:punct:]]", " ", a)
a<-gsub('[0-9]+', '', a)
a<-gsub("[:(:]", "",a)
a<-gsub("[:):]", "",a)
a<-gsub("\\{|\\}", "",a)
a<-gsub("\\[|\\]", "",a)
a<-gsub("[:+:]", "",a)
a<-gsub("[:-:]", "",a)
a<-gsub(c("\\<it\\>"), "",a)
a<-gsub(c("\\<a\\>"), "",a)
a<-gsub(c("\\<b\\>"), "",a)
a<-gsub(c("\\<c\\>"), "",a)
a<-gsub(c("\\<d\\>"), "",a)
a<-gsub(c("\\<e\\>"), "",a)
a<-gsub(c("\\<f\\>"), "",a)
a<-gsub(c("\\<g\\>"), "",a)
a<-gsub(c("\\<h\\>"), "",a)
a<-gsub(c("\\<j\\>"), "",a)
a<-gsub(c("\\<k\\>"), "",a)
a<-gsub(c("\\<l\\>"), "",a)
a<-gsub(c("\\<m\\>"), "",a)
a<-gsub(c("\\<n\\>"), "",a)
a<-gsub(c("\\<o\\>"), "",a)
a<-gsub(c("\\<p\\>"), "",a)
a<-gsub(c("\\<q\\>"), "",a)
a<-gsub(c("\\<s\\>"), "",a)
a<-gsub(c("\\<t\\>"), "",a)
a<-gsub(c("\\<r\\>"), "",a)
a<-gsub(c("\\<u\\>"), "",a)
a<-gsub(c("\\<v\\>"), "",a)
a<-gsub(c("\\<w\\>"), "",a)
a<-gsub(c("\\<x\\>"), "",a)
a<-gsub(c("\\<y\\>"), "",a)
a<-gsub(c("\\<z\\>"), "",a)
a<-gsub(c("\\<the\\>"), "",a)
a<-gsub(c("\\<at\\>"), "",a)
a<-gsub(c("\\<of\\>"), "",a)
a<-gsub(c("\\<by\\>"), "",a)
a<-gsub(c("\\<on\\>"), "",a)
a<-gsub(c("\\<is\\>"), "",a)
a<-gsub(c("\\<are\\>"), "",a)
a<-gsub(c("\\<am\\>"), "",a)
a<-gsub(c("\\<was\\>"), "",a)
a<-gsub(c("\\<were\\>"), "",a)
a<-gsub(c("\\<can\\>"), "",a)
a<-gsub(c("\\<could\\>"), "",a)
a<-gsub(c("\\<would\\>"), "",a)
a<-gsub(c("\\<should\\>"), "",a)
a<-gsub(c("\\<shall\\>"), "",a)
a<-gsub(c("\\<will\\>"), "",a)
a<-gsub(c("\\<i\\>"), "",a)
a<-gsub(c("\\<in\\>"), "",a)
a<-gsub(c("\\<to\\>"), "",a)
a<-gsub(c("\\<so\\>"), "",a)
a<-gsub(c("\\<may\\>"), "",a)
a<-gsub(c("\\<might\\>"), "",a)
a<-gsub(c("\\<must\\>"), "",a)
a<-gsub(c("\\<has\\>"), "",a)
a<-gsub(c("\\<have\\>"), "",a)
a<-gsub(c("\\<had\\>"), "",a)
a<-gsub(c("\\<been\\>"), "",a)
a<-gsub(c("\\<be\\>"), "",a)
a<-gsub(c("\\<being\\>"), "",a)
a<-gsub(c("\\<do\\>"), "",a)
a<-gsub(c("\\<does\\>"), "",a)
a<-gsub(c("\\<did\\>"), "",a)
a<-gsub(c("\\<doing\\>"), "",a)
a<-gsub(c("\\<you\\>"), "",a)
a<-gsub(c("\\<your\\>"), "",a)
a<-gsub(c("\\<they\\>"), "",a)
a<-gsub(c("\\<we\\>"), "",a)
a<-gsub(c("\\<them\\>"), "",a)
a<-gsub(c("\\<me\\>"), "",a)
a<-gsub(c("\\<my\\>"), "",a)
a<-gsub(c("\\<mine\\>"), "",a)
a<-gsub(c("\\<their\\>"), "",a)
a<-gsub(c("\\<having\\>"), "",a)
a<-gsub(c("\\<he\\>"), "",a)
a<-gsub(c("\\<his\\>"), "",a)
a<-gsub(c("\\<she\\>"), "",a)
a<-gsub(c("\\<her\\>"), "",a)
a<-gsub(c("\\<that\\>"), "",a)
a<-gsub(c("\\<this\\>"), "",a)
a<-gsub(c("\\<those\\>"), "",a)
a<-gsub(c("\\<now\\>"), "",a)
a<-gsub(c("\\<us\\>"), "",a)
a<-gsub(c("\\<for\\>"), "",a)
a<-gsub("\\", "", a, fixed=TRUE)



b<-(df$citation.title)


ind1<-strsplit(as.character(a), " ")

ind2<-strsplit(as.character(b), " ")


w<-length(strsplit(as.character(a), " "))

for(i in 1:w)
{ print(i)
count<-length(strsplit(as.character(a), " ")[[i]])
 if (count!=0){
  for (j in 1:count)
   { 
    #print(ALTMETRIC_ID)
    #print(ind1[[i]][j])
    #print(ind2[i])
    temp<-grepl(ind1[[i]][j],ind2[i],ignore.case=TRUE,fixed = TRUE)
    #temp=!is.na(temp)
     #print(temp)
   #temp<-grepl("(?=(?i)na(*SKIP)(*F))|[[ind1[[i]][j]]]",ind2[i],perl=TRUE)
     
  if (temp=='TRUE' & !is.na(temp))
        {  
             
          # df[i,3]<-sapply(seq_along(ind1), function(i)gsub(ind1[[i]][j], "",df[i,3]))
           
          tweet[[i]][]<-gsub(ind1[[i]][j], "",tweet[[i]][])
          
           		
         }
         
	  }  
  }

tweet[[i]]<-paste(tweet[[i]], collapse=" ")

}


TEXT<-unlist(tweet)


#max.len = max(length(ALTMETRIC_ID), length(TWEET_ID),length(TEXT),length(citation.title))
#ALTMETRIC_ID = c(ALTMETRIC_ID, rep(NA, max.len - length(ALTMETRIC_ID)))
#TWEET_ID = c(TWEET_ID, rep(NA, max.len - length(TWEET_ID)))
#TEXT = c(TEXT, rep(NA, max.len - length(TEXT)))
#citation.title = c(citation.title, rep(NA, max.len - length(citation.title)))


data <- data.frame(id2,TEXT,citation.title)

write.csv(data, file=paste(listi,"output.csv"))
}



