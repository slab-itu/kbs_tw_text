#This R script is used to separate non english tweets from english language tweets

#Place input files (csv format) in below directory or update the directory accordingly

setwd("E:/MS Study/Thesis/Twitter Data")


df<-read.csv("input.csv",row.names=NULL,stringsAsFactors=FALSE)

len<-length(df$TEXT)

df1<-data.frame()

df2<-data.frame()
for (i in 1:len)
{
print(i)
library(cldr)

result<-detectLanguage(df$TEXT[i])
#print(df$TEXT[i])
#print(result[1])
#print(result[1])
if(result[1]=='ENGLISH')
{
#print(df[i,])
#print(df1)
df1<-do.call("rbind", list(df[i,], df1))

}
else
{
df2<-do.call("rbind", list(df[i,], df2))
}
}

#Saving English tweets into file

write.csv(df1, file="tweets witout terms_Final_Eng.csv")


#Saving non english tweets into file
write.csv(df2, file="tweets witout terms_Final_Non-Eng.csv")


